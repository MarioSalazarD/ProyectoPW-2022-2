export default[{
    id: "1",
    imgsrc : "img/Nvidia.jpg",
    title: "NVIDIA GEFORCE RTX 3070 8GB (VR READY)",
    price: "Price: $679",
    titledetail1: "CHIPSET MANUFACTURER",
    detail1: "NVIDIA",
    titledetail2: "GPU",
    detail2: "Geforce RTX 3070",
    titledetail3: "CORE CLOCK",
    detail3: "1530 MHz",
    titledetail4: "BOOST CLOCK",
    detail4: "OC Mode: 1800 Mhz Gaming Mode (Default) 1770 MHz",
    titledetail5: "CUDA CORES",
    detail5: "1280",

    
},
{
    id: "2",
    imgsrc : "img/intelcore.jpg",
    title: "INTEL CORE I7-12700F 12-CORE",
    price: "Price: $359",
    titledetail1: "PROCESSOR NUMBER",
    detail1: "i7-12700F",
    titledetail2: "NUMBER OF CORES",
    detail2: "12",
    titledetail3: "MAXIMUN TURBO FREQUENCY",
    detail3: "4,90 GHz",
    titledetail4: "MAXIUM MEMORY SIZE",
    detail4: "128 GB",
    titledetail5: "CACHE",
    detail5: "25 MB Intel® Smart Cache",
   
},
{
    id: "3",
    imgsrc : "img/keyboard.jpg",
    title: "KEYBOARD AND MOUSE RAZER",
    price: "Price: $39",
    titledetail1: "MODEL KEYBOARD",
    detail1: "Cynosa Chroma Lite",
    titledetail2: "KEYBOARD BACKLIGHT COLOR",
    detail2: "Green",
    titledetail3: "MODEL MOUSE",
    detail3: "Abyssus Lite",
    titledetail4: "MOUSE SENSOR RESOLUTION",
    detail4: "6400 dpi",
    titledetail5: "MOUSE COLOR",
    detail5: "Green",
},
{
    id: "4",
    imgsrc : "img/SSD.jpg",
    title: "1TB NVME M.2",
    price: "Price: $99",

},
{
    id: "5",
    imgsrc : "img/CASE.jpg",
    title: "COOLER MASTER TD500 RGB",
    price: "Price: $99",

},
{
    id: "6",
    imgsrc : "img/setup.jpg",
    title: "BUILD + SETUP + TESTING + WARRANTY",
    price: "Price: $99",
}
]

